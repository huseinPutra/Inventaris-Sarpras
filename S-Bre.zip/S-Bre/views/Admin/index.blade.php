@extends('layouts.template')

@section('content')
    <h1>Form Admin</h1>
@endsection